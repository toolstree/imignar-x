(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(){return`

<section class="hero">

<div class="hero-card">

<div class="hero-badge">

🌿 IMIGNARX

</div>

<h1>

Walk Into<br>

Your Nature

</h1>

<p>

Discover your natural thinking style through
a peaceful interactive journey inspired by
forests, rivers, flowers and quiet reflection.

</p>

<button id="beginJourney">

Begin Your Journey →

</button>

</div>

</section>

`}var t={mount(t){t.innerHTML=`

<div id="screen-hero">

${e()}

</div>

<div
id="screen-quiz"
class="hidden">

</div>

<div
id="screen-results"
class="hidden">

</div>

`}},n=[{id:1,scene:`forest`,chapter:`Chapter One`,title:`The Forest Awakens`,text:`Morning light filters through ancient trees. Every path feels equally welcoming. Which instinct do you follow first?`,answers:[`🌿 Walk slowly in silence`,`🌄 Explore every trail`,`🌳 Rest beneath an old tree`,`🌼 Find other travellers`]},{id:2,scene:`river`,chapter:`Chapter Two`,title:`The Crystal River`,text:`A calm river reflects the blue morning sky. The current whispers softly beside you.`,answers:[`💧 Sit beside the water`,`🌉 Cross immediately`,`🚶 Follow the river`,`🪨 Watch before acting`]},{id:3,scene:`flowers`,chapter:`Chapter Three`,title:`The Meadow`,text:`Thousands of flowers bloom in every direction while butterflies dance around them.`,answers:[`🌸 Wander peacefully`,`📷 Capture the beauty`,`🦋 Follow butterflies`,`☀️ Lie down and relax`]},{id:4,scene:`mountain`,chapter:`Chapter Four`,title:`The Mountain Trail`,text:`The climb becomes steeper. The view grows wider with every step.`,answers:[`🥾 Keep climbing`,`🪨 Rest halfway`,`📖 Observe everything`,`🌤 Enjoy the scenery`]},{id:5,scene:`summit`,chapter:`Chapter Five`,title:`The Quiet Summit`,text:`Everything below becomes silent. One thought naturally fills your mind.`,answers:[`🙏 Gratitude`,`✨ Curiosity`,`🌅 Hope`,`🌿 Inner Peace`]},{id:6,scene:`forest`,chapter:`Chapter Six`,title:`The Ancient Oak`,text:`An enormous tree has stood here for centuries.`,answers:[`🌳 Touch the bark`,`📖 Study its age`,`🍃 Sit beneath it`,`🚶 Continue walking`]},{id:7,scene:`river`,chapter:`Chapter Seven`,title:`The Waterfall`,text:`A waterfall echoes through the valley.`,answers:[`💦 Walk closer`,`📷 Photograph it`,`🧘 Meditate`,`🚶 Keep moving`]},{id:8,scene:`flowers`,chapter:`Chapter Eight`,title:`The Lavender Field`,text:`Purple flowers stretch beyond the horizon.`,answers:[`💜 Smell the flowers`,`🌸 Walk slowly`,`☀️ Rest`,`🦋 Watch nature`]},{id:9,scene:`mountain`,chapter:`Chapter Nine`,title:`Cloud Path`,text:`Clouds drift across the trail while cool winds surround you.`,answers:[`☁️ Continue upward`,`🪨 Pause`,`📖 Reflect`,`🌄 Watch the sky`]},{id:10,scene:`summit`,chapter:`Chapter Ten`,title:`Golden Horizon`,text:`The sun begins to set over distant mountains.`,answers:[`🌅 Watch silently`,`🙏 Feel grateful`,`📷 Capture it`,`✨ Dream ahead`]},{id:11,scene:`forest`,chapter:`Chapter Eleven`,title:`Birdsong`,text:`The forest becomes alive with birds singing.`,answers:[`🎵 Listen carefully`,`🪶 Follow them`,`🌳 Rest`,`🚶 Continue`]},{id:12,scene:`river`,chapter:`Chapter Twelve`,title:`Morning Mist`,text:`Mist slowly rises above calm water.`,answers:[`🌫 Walk through it`,`🧘 Pause`,`🚣 Continue`,`👀 Observe`]},{id:13,scene:`flowers`,chapter:`Chapter Thirteen`,title:`Wild Garden`,text:`Nature feels completely untouched.`,answers:[`🌼 Wander`,`🌸 Sit quietly`,`🐝 Watch bees`,`☀️ Smile`]},{id:14,scene:`mountain`,chapter:`Chapter Fourteen`,title:`The Final Climb`,text:`Only a few steps remain.`,answers:[`🥾 Push forward`,`💨 Slow down`,`🌄 Look behind`,`🙏 Appreciate`]},{id:15,scene:`summit`,chapter:`Chapter Fifteen`,title:`Your Reflection`,text:`Looking across everything you've experienced, what remains strongest?`,answers:[`🌿 Peace`,`🔥 Purpose`,`💙 Connection`,`✨ Possibility`]}];function r(e,t,n){return`

<section class="quiz fade ${e.scene}">

<div class="quiz-shell">

<div class="progress">

<div
class="progress-fill"
style="width:${t/n*100}%">
</div>

</div>

<div class="chapter-pill">

${e.chapter}

</div>

<h1>

${e.title}

</h1>

<p class="story">

${e.text}

</p>

<div class="answers">

${e.answers.map((e,t)=>`

<button
class="answer"
data-answer="${t}">

<span class="answer-text">

${e}

</span>

<span class="arrow">

→

</span>

</button>

`).join(``)}

</div>

<div class="progress-text">

Question ${t} of ${n}

</div>

</div>

</section>

`}function i(e){return`

<section class="results fade">

<div class="results-shell">

<div class="result-badge">

🌿 YOUR NATURE

</div>

<h1>

${e.archetype.title}

</h1>

<p class="result-description">

${e.archetype.description}

</p>

<div class="insights">

<div class="insight">

<h3>Thinking Style</h3>

<p>

${e.archetype.title.includes(`Sage`)?`Thoughtful • Analytical • Patient`:e.archetype.title.includes(`Explorer`)?`Curious • Adventurous • Adaptive`:e.archetype.title.includes(`Guardian`)?`Reliable • Caring • Stable`:`Creative • Expressive • Imaginative`}

</p>

</div>

<div class="insight">

<h3>Growth Path</h3>

<p>

Continue choosing calm over noise.

Small intentional actions create
lasting personal growth.

</p>

</div>

<div class="insight">

<h3>Daily Reflection</h3>

<p>

Spend ten quiet minutes today
without distractions and simply
observe your thoughts.

</p>

</div>

<div class="insight">

<h3>Nature Reminder</h3>

<p>

Your strongest version appears
when your environment is calm,
beautiful and intentional.

</p>

</div>

</div>

<div class="score-title">

Personality Balance

</div>

<div class="bars">

${Object.entries(e.scores).map(([e,t])=>`

<div class="bar">

<div class="bar-label">

${e}

</div>

<div class="bar-track">

<div
class="bar-fill"
style="width:${t/15*100}%">

</div>

</div>

<div class="bar-value">

${t}

</div>

</div>

`).join(``)}

</div>

<button
id="restartJourney">

Begin Another Journey →

</button>

</div>

</section>

`}function a(e){return`

<section class="email-capture fade">

<div class="email-card">

<div class="email-badge">

🔓 Unlock Your Complete Report

</div>

<h2>

${e.archetype.title}

</h2>

<p>

Your complete Nature Report is ready.

Unlock instantly:

• Full psychology profile

• Growth roadmap

• Garden permanently saved

• Weekly reflection emails

</p>

<form id="emailForm">

<input

type="email"

id="email"

placeholder="Enter your email"

required

/>

<button>

Unlock My Report →

</button>

</form>

<div id="emailMessage"></div>

</div>

</section>

`}function o(e){return e?.length?`

<section class="history">

<h2>Journey History</h2>

<div class="history-grid">

${e.map(e=>`

<div class="history-card">

<h3>${e.archetype}</h3>

<p>${e.date}</p>

</div>

`).join(``)}

</div>

</section>

`:`
<div class="history-empty">
No journeys yet.
</div>
`}var s={SAGE:{title:`The Sage 🌳`,color:`#5EA887`,description:`You value wisdom, calm thinking and meaningful reflection.`},EXPLORER:{title:`The Explorer 🏔`,color:`#4DA8DA`,description:`You are energized by curiosity, discovery and new experiences.`},GUARDIAN:{title:`The Guardian 🌿`,color:`#74C69D`,description:`You create stability, loyalty and emotional safety.`},CREATOR:{title:`The Creator 🌸`,color:`#D88BC2`,description:`You naturally imagine, build and inspire beautiful ideas.`}},c=new class{calculate(e){let t={SAGE:0,EXPLORER:0,GUARDIAN:0,CREATOR:0};return e.forEach(e=>{switch(Number(e)){case 0:t.GUARDIAN++;break;case 1:t.EXPLORER++;break;case 2:t.SAGE++;break;case 3:t.CREATOR++;break}}),{scores:t,archetype:s[Object.keys(t).reduce((e,n)=>t[e]>t[n]?e:n)]}}};function l(e){let t=Math.max(1,Math.floor(e/3)),n=Math.max(6,e*4),r=Math.floor(e/5);return`

<section class="garden fade">

<div class="garden-sky"></div>

<div class="garden-card">

<div class="garden-header">

<h1>

🌿 Your Living Garden

</h1>

<p>

Every completed journey helps your inner
garden grow stronger.

</p>

</div>

<div class="garden-world">

<div class="sun"></div>

<div class="ground"></div>

<div class="trees">

${Array.from({length:t}).map(()=>`

<div class="tree">

🌳

</div>

`).join(``)}

</div>

<div class="flowers">

${Array.from({length:n}).map(()=>`

<span>

🌼

</span>

`).join(``)}

</div>

<div class="butterflies">

${Array.from({length:r}).map(()=>`

<span>

🦋

</span>

`).join(``)}

</div>

</div>

</div>

</section>

`}var u=new class{render(e=15){let t=document.getElementById(`screen-results`);t&&t.insertAdjacentHTML(`beforeend`,l(e))}},d=`imignarx-v4`,f=new class{load(){try{return JSON.parse(localStorage.getItem(d))||{journeys:[]}}catch{return{journeys:[]}}}save(e){localStorage.setItem(d,JSON.stringify(e))}addJourney(e){let t=this.load();t.journeys.unshift({date:new Date().toLocaleString(),archetype:e.archetype.title,scores:e.scores}),this.save(t)}history(){return this.load().journeys}clear(){localStorage.removeItem(d)}},p=new class{constructor(){this.index=0,this.answers=[]}start(){this.index=0,this.answers=[],this.render()}render(){let e=document.getElementById(`screen-quiz`);e&&(e.innerHTML=r(n[this.index],this.index+1,n.length),this.bind())}bind(){document.querySelectorAll(`.answer`).forEach(e=>{e.onclick=()=>{this.answers.push(Number(e.dataset.answer)),this.index++,this.index>=n.length?this.finish():this.render()}})}finish(){let e=document.getElementById(`screen-quiz`),t=document.getElementById(`screen-results`);if(!e||!t)return;e.classList.add(`hidden`),t.classList.remove(`hidden`);let n=c.calculate(this.answers);f.addJourney(n),t.innerHTML=i(n),t.insertAdjacentHTML(`beforeend`,o(f.history())),t.insertAdjacentHTML(`beforeend`,a(n)),u.render(this.answers.length);let r=document.getElementById(`emailForm`);r&&r.addEventListener(`submit`,e=>{e.preventDefault();let t=document.getElementById(`email`).value.trim(),n=/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(t);document.getElementById(`emailMessage`).textContent=n?`✅ Report unlocked!`:`Please enter a valid email.`});let s=document.getElementById(`restartJourney`);s&&(s.onclick=()=>{location.reload()})}},m={bind(){document.addEventListener(`click`,e=>{if(e.target.id===`beginJourney`){let e=document.getElementById(`screen-hero`),t=document.getElementById(`screen-quiz`);e.classList.add(`screen-exit`),setTimeout(()=>{e.classList.add(`hidden`),t.classList.remove(`hidden`),p.start()},500)}})}},h={start(){let e=document.querySelector(`#app`);if(!e)throw Error(`#app not found`);t.mount(e),m.bind(),console.log(`🌿 ImignarX V4 Started`)}};document.addEventListener(`DOMContentLoaded`,()=>{h.start()});